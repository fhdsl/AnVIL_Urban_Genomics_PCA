# (PART\*) Background Lectures {-}

# SNPs

This lecture module introduces the concepts of genetic variation and SNPs.

**Learning Objectives**

1. Learn what SNPs are 
1. Understand why whole genome SNPs are useful in genetics



You can view and download the Google Slides here
